const Collection = require('../models/collectionModel')

const collectionController = {

}

module.exports = collectionController