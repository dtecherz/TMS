exports.MONGO_URL = process.env.MONGO_URL || "mongodb://localhost:27017/Ecomm"
exports.PORT = process.env.PORT || "3030"
exports.deliver_charges = process.env.Delivery_Charges || 200
exports.MODE = process.env.MODE || "development"